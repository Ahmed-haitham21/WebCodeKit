import { NextResponse } from "next/server";
import { callAnthropic, sanitizeHistory, CHAT_SYSTEM_PROMPT } from "@/lib/anthropic";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

export const runtime = "nodejs"; // محتاجين Node runtime عشان process.env و fetch الكامل

export async function POST(req) {
  const ip = getClientIp(req);
  const { allowed, resetMs } = checkRateLimit(ip);
  if (!allowed) {
    return NextResponse.json(
      { error: "طلبات كثيرة جداً، حاول بعد لحظات." },
      { status: 429, headers: { "Retry-After": String(Math.ceil(resetMs / 1000)) } }
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    const { message, history } = body || {};

    if (!message || typeof message !== "string") {
      return NextResponse.json({ error: "message مطلوب." }, { status: 400 });
    }

    const messages = [...sanitizeHistory(history), { role: "user", content: message }];

    const text = await callAnthropic({
      system: CHAT_SYSTEM_PROMPT,
      messages,
      max_tokens: 1000,
    });

    return NextResponse.json({ reply: text });
  } catch (err) {
    console.error("Chat error:", err.message);
    return NextResponse.json({ error: "حصل خطأ في توليد الرد." }, { status: 500 });
  }
}
