import { NextResponse } from "next/server";
import { MODEL } from "@/lib/anthropic";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({ status: "ok", model: MODEL });
}
