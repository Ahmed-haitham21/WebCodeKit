export const metadata = {
  title: "WebCodeKit",
};

// الموقع نفسه HTML/CSS/JS ثابت وبيتقدّم من public/ (index.html, systems.html...).
// الـ App Router هنا مسؤول بس عن الـ API routes (app/api/*).
// اللايوت ده مجرد passthrough مطلوب من Next.js.
export default function RootLayout({ children }) {
  return children;
}
