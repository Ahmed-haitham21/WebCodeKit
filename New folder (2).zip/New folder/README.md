# WebCodeKit — Next.js Backend

الموقع اتنقل من Express (`server.js`) إلى **Next.js API Routes**. الصفحات الثابتة
(HTML/CSS/JS) متغيرتش خالص — لسه شغالة زي ما هي، بس دلوقتي بتتقدّم من مجلد
`public/` وبتتخدم من خلال Next.js بدل Express.

## هيكل المشروع

```
public/            كل صفحات الموقع القديمة زي ما هي (index.html, systems.html, ...)
app/api/chat/       POST /api/chat    — الشات العادي
app/api/code/       POST /api/code    — توليد كومبوننت من وصف نصي
app/api/vision/     POST /api/vision  — Design-to-Code من صورة
app/api/health/     GET  /api/health  — health check
lib/anthropic.js    كل منطق التواصل مع Anthropic API في مكان واحد
lib/rateLimit.js    Rate limiting بسيط لكل IP
next.config.mjs     rewrites + هيدرز أمان + كاش
```

الفرونت-إند (`smart-ai.js`) مش محتاج أي تعديل — لسه بينده على نفس المسارات
النسبية `/api/chat` و `/api/code` و `/api/vision`، وهي دلوقتي بتتخدم من Next.js
بدل Express بنفس الشكل بالظبط.

## التشغيل محلياً

```bash
npm install
cp .env.local.example .env.local   # وحط مفتاح Anthropic بتاعك جوه
npm run dev                        # يشتغل على http://localhost:3000
```

الموقع هيفتح على `http://localhost:3000/` (بيتحول تلقائياً لـ `index.html`
عن طريق rewrite في `next.config.mjs`). أي صفحة تانية زي `/systems.html` أو
`/smart-ai.html` هتشتغل بنفس الأسماء القديمة بالظبط.

## البناء للإنتاج

```bash
npm run build
npm run start
```

## اللي اتظبط عشان يبقى أكفأ واحترافي أكتر

1. **الأمان**
   - مفتاح `ANTHROPIC_API_KEY` فاضل على السيرفر بس (`.env.local`) وميوصلش
     للمتصفح خالص — بالظبط زي قبل.
   - هيدرز أمان تلقائية على كل response: `X-Content-Type-Options`,
     `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`.
   - هيدر `X-Powered-By` بتاع Next.js اتشال عشان مايبانش الفريموورك للزوار.
   - أي رسالة خطأ حقيقية من Anthropic API بتتسجل في السيرفر (`console.error`)
     ومبترجعش للعميل — العميل بياخد رسالة عامة بس.

2. **الأداء**
   - Compression (gzip/brotli) شغالة تلقائياً على كل الردود.
   - كاش طويل المدى (`max-age=31536000, immutable`) على الأيقونات الثابتة.
   - كاش أسبوع (`max-age=604800`) على ملفات `.min.css` / `.min.js`.
   - الـ API routes (`/api/*`) دايماً `no-store` عشان الردود متتخزنش غلط في
     أي كاش وسيط (CDN/proxy) وتوصل رد قديم أو لحد تاني بالغلط.

3. **الموثوقية**
   - Rate limiting: 30 طلب/دقيقة لكل IP على كل الـ API routes، بنفس الحد
     اللي كان في Express، مع رجوع `429` + هيدر `Retry-After` بدل ما السيرفر
     يتسحن.
   - Validation صريح على كل route (`message مطلوب`, `imageBase64 و imageType
     مطلوبين`, ...) قبل أي نداء لـ Anthropic — بيوفر تكلفة استدعاءات فاشلة.
   - أي مسار مش موجود بيتحول لصفحة `404.html` القديمة بتاعتك بدل صفحة Next.js
     الافتراضية.

## ⚠️ نقطة مهمة قبل ما تنشر على إنتاج حقيقي بحركة عالية

الـ Rate limiter الحالي شغال **في الذاكرة (in-memory)** — يعني هو مثالي على
سيرفر واحد طويل العمر (VPS، أو `next start` على Docker container واحد).

لو هتنشر على منصة serverless بتوزّع الطلبات على أكتر من نسخة (زي Vercel
Functions وقت الحمل العالي)، كل نسخة هيبقى عندها عداد منفصل، يعني الحد
الفعلي هيبقى أعلى شوية من 30/دقيقة. للإنتاج على نطاق واسع، ابدّل
`lib/rateLimit.js` بحل مشترك زي:

```bash
npm install @upstash/ratelimit @upstash/redis
```

وقولّي لو عايزني أظبطهولك بالطريقة دي مباشرة.

## النشر (Deployment)

أسهل طريقة هي **Vercel** (نفس الشركة صاحبة Next.js):
1. ادفع المشروع على GitHub.
2. اربطه بـ Vercel واستورد الريبو.
3. حط `ANTHROPIC_API_KEY` (و`ANTHROPIC_MODEL` لو عايز) في Environment
   Variables في إعدادات المشروع على Vercel — مش في أي ملف بيتنشر مع الكود.
4. Vercel هيبني وينشر تلقائي، وهتاخد CDN عالمي + HTTPS + تحجيم تلقائي مجاناً.

بديل: أي VPS عادي (`npm run build && npm run start` خلف Nginx/PM2) لو عايز
تتحكم في السيرفر بنفسك.
