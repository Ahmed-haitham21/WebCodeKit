// Card Data - Complete HTML Template and CSS for each card
const cardData = {
  1: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Your CSS File -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-1">
    <div class="card-icon"><i class="fas fa-rocket"></i></div>
    <h3>🚀 إطلاق جديد</h3>
    <p>اكتشف أحدث منتجاتنا المتميزة التي ستغير طريقة عملك</p>
    <button>اطلب الآن</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-1 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(145deg, #ffffff, #f0f0f0);
    color: #333;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-1:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-1 .card-icon {
    font-size: 50px;
    color: #4a90d9;
    margin-bottom: 20px;
}

.card-1 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-1 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-1 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, #4a90d9, #357abd);
    color: white;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-1 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  2: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-2">
    <div class="card-icon"><i class="fas fa-gift"></i></div>
    <h3>🎁 عرض خاص</h3>
    <p>خصم 50% على جميع المنتجات لمدة أيام محدودة</p>
    <button>احصل على العرض</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-2 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
    color: white;
    border: 4px solid #fff;
    box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-2:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-2 .card-icon {
    font-size: 50px;
    width: 80px;
    height: 80px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
}

.card-2 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-2 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-2 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: white;
    color: #ff6b6b;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-2 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  3: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-3">
    <div class="card-badge">جديد</div>
    <div class="card-icon"><i class="fas fa-star"></i></div>
    <h3>⭐ منتج مميز</h3>
    <p>الأكثر مبيعاً هذا الشهر - جودة استثنائية</p>
    <button>تصفح المزيد</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-3 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
    padding: 35px 30px 50px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
}

.card-3:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-3 .card-badge {
    position: absolute;
    top: 20px;
    right: 20px;
    background: #ff6b6b;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.card-3 .card-icon {
    font-size: 50px;
    color: #ffd700;
    margin-bottom: 20px;
}

.card-3 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-3 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-3 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: white;
    color: #667eea;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-3 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  4: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-4">
    <div class="card-icon"><i class="fas fa-crown"></i></div>
    <h3>👑 باقة VIP</h3>
    <p>العضوية الحصرية واحصل على مميزات لا نهائية</p>
    <button>اشترك الآن</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-4 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(145deg, #1e1e2f, #2d2d44);
    color: white;
    box-shadow: 0 0 30px rgba(255, 215, 0, 0.3), 0 10px 30px rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 215, 0, 0.3);
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-4:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-4 .card-icon {
    font-size: 50px;
    color: #ffd700;
    text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
    margin-bottom: 20px;
}

.card-4 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-4 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-4 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, #ffd700, #ffaa00);
    color: #1e1e2f;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-4 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  5: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-5">
    <div class="card-icon"><i class="fas fa-leaf"></i></div>
    <h3>🌿 صديق للبيئة</h3>
    <p>منتجات طبيعية 100% آمنة على صحتك والبيئة</p>
    <button>اعرف المزيد</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-5 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-5:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-5 .card-icon {
    font-size: 50px;
    color: #00d4aa;
    margin-bottom: 20px;
}

.card-5 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-5 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-5 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, #00d4aa, #00a885);
    color: white;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-5 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  6: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-6">
    <div class="card-stripe"></div>
    <div class="card-icon"><i class="fas fa-bolt"></i></div>
    <h3>⚡ سرعة البرق</h3>
    <p>توصيل خلال ساعة واحدة - طلبك في بابك</p>
    <button>اطلب سريعاً</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-6 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(145deg, #4ecdc4, #44a08d);
    color: white;
    position: relative;
    overflow: hidden;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-6::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-6 .card-icon {
    font-size: 50px;
    color: #2c3e50;
    margin-bottom: 20px;
}

.card-6 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-6 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-6 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: white;
    color: #4ecdc4;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-6 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  7: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-7">
    <div class="card-icon"><i class="fas fa-shield-alt"></i></div>
    <h3>🛡️ أمان تام</h3>
    <p>ضمان 5 سنوات على جميع منتجاتنا - اطمئن</p>
    <button>شاهد الضمان</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-7 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(145deg, #a8edea, #fed6e3);
    color: #333;
    border: 3px solid transparent;
    background-clip: padding-box;
    position: relative;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-7::before {
    content: '';
    position: absolute;
    top: -3px;
    left: -3px;
    right: -3px;
    bottom: -3px;
    background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
    border-radius: 23px;
    z-index: -1;
}

.card-7:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-7 .card-icon {
    font-size: 50px;
    color: #667eea;
    margin-bottom: 20px;
}

.card-7 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-7 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-7 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-7 button:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}`,
  },
  8: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-8">
    <div class="card-icon"><i class="fas fa-magic"></i></div>
    <h3>✨ سحر خاص</h3>
    <p>تجربة تسوق سحرية مع عروضنا الحصرية</p>
    <button>ابدأ التجربة</button>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-8 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: #0d0d0d;
    color: white;
    box-shadow: 0 0 20px rgba(0, 255, 255, 0.3), inset 0 0 20px rgba(0, 255, 255, 0.1);
    border: 1px solid rgba(0, 255, 255, 0.5);
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-8:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-8 .card-icon {
    font-size: 50px;
    color: #00ffff;
    text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff;
    animation: neonPulse 2s infinite;
    margin-bottom: 20px;
}

@keyframes neonPulse {
    0%, 100% { text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff; }
    50% { text-shadow: 0 0 20px #00ffff, 0 0 40px #00ffff, 0 0 60px #00ffff; }
}

.card-8 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-8 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-8 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: transparent;
    color: #00ffff;
    border: 2px solid #00ffff;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}

.card-8 button:hover {
    background: #00ffff;
    color: #0d0d0d;
}`,
  },
  9: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-9">
    <div class="card-top">
        <div class="card-icon"><i class="fas fa-fire"></i></div>
    </div>
    <div class="card-bottom">
        <h3>🔥 الأكثر شعبية</h3>
        <p>انضم لألف عميل سعيد - رضاهم يتحدث</p>
        <button>انضم لهم</button>
    </div>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-9 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: transparent;
    padding: 0;
    color: white;
    overflow: hidden;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-9:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-9 .card-top {
    background: linear-gradient(135deg, #ff9a56, #ff6b6b);
    padding: 30px;
    clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
    padding-bottom: 50px;
}

.card-9 .card-bottom {
    background: linear-gradient(135deg, #2d2d44, #1a1a2e);
    padding: 30px;
    margin-top: -30px;
}

.card-9 .card-icon {
    font-size: 50px;
    color: white;
    margin-bottom: 20px;
}

.card-9 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-9 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-9 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, #ff9a56, #ff6b6b);
    color: white;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}`,
  },
  10: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-10">
    <div class="card-content">
        <div class="card-icon"><i class="fas fa-gem"></i></div>
        <h3>💎 قيمة استثنائية</h3>
        <p>جودة عالية بسعر لا يُصدق - وفر أكثر</p>
        <button>تسوق الآن</button>
    </div>
</div>

</body>
</html>`,
    css: `/* Card Styles */
.card-10 {
    width: 350px;
    height: auto;
    min-height: 320px;
    background: linear-gradient(rgba(102, 126, 234, 0.9), rgba(118, 75, 162, 0.9));
    color: white;
    box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
}

.card-10:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.card-10 .card-icon {
    font-size: 50px;
    color: #ffd700;
    margin-bottom: 20px;
}

.card-10 h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}

.card-10 p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}

.card-10 button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    background: white;
    color: #667eea;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}`,
  },

  // Cards 11-40 — unique templates
  11: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 11</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-11">
    <div class="card-icon"><i class="fas fa-percent"></i></div>
    <h3>💰 وفّر 70%</h3>
    <p>أفضل الأسعار في السوق - لا تُضيع الفرصة</p>
    <button>وفر الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}`,
  },
  12: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 12</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-12">
    <div class="card-icon"><i class="fas fa-snowflake"></i></div>
    <h3>❄️ عرض الشتاء</h3>
    <p>منتجات الشتاء بأسعار مخفضة جداً</p>
    <button>تصفح الشتاء</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}`,
  },
  13: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 13</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-13">
    <div class="card-icon"><i class="fas fa-headset"></i></div>
    <h3>🎧 دعم 24/7</h3>
    <p>فريق دعم متاح على مدار الساعة لخدمتك</p>
    <button>تواصل معنا</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}`,
  },
  14: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 14</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-14">
    <div class="card-icon"><i class="fas fa-plane"></i></div>
    <h3>✈️ شحن مجاني</h3>
    <p>شحن مجاني لجميع الطلبات فوق 200 ريال</p>
    <button>اطلب مجاناً</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}`,
  },
  15: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 15</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-15">
    <div class="card-icon"><i class="fas fa-box-open"></i></div>
    <h3>📦 package مجاني</h3>
    <p>هدايا مجانية مع كل طلب - مفاجآت تنتظرك</p>
    <button>احصل على هديتك</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}`,
  },
  16: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 16</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-16">
    <div class="card-icon"><i class="fas fa-heart"></i></div>
    <h3>❤️ مصنوع بحب</h3>
    <p>كل منتج يصنع بأقصى درجات الدقة والعناية</p>
    <button>اعرف قصتنا</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}

.card-15 .card-icon {
  transform: translateZ(30px);
}
.card-15 h3,
.card-15 p,
.card-15 button {
  transform: translateZ(20px);
}
.card-15 button {
  background: white;
  color: #fa709a;
}

/* ==================== CARD 16 - متدرج ==================== */
.card-16 {
  background: linear-gradient(
    45deg,
    #ff6b6b,
    #feca57,
    #48dbfb,
    #ff9ff3,
    #f368e0
  );
  background-size: 400% 400%;
  animation: gradientBG 5s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}`,
  },
  17: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 17</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-17">
    <div class="card-icon"><i class="fas fa-laptop-code"></i></div>
    <h3>💻 تقنية حديثة</h3>
    <p>أحدث التقنيات والابتكارات في منتجنا</p>
    <button>استكشف التقنية</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}

.card-15 .card-icon {
  transform: translateZ(30px);
}
.card-15 h3,
.card-15 p,
.card-15 button {
  transform: translateZ(20px);
}
.card-15 button {
  background: white;
  color: #fa709a;
}

/* ==================== CARD 16 - متدرج ==================== */
.card-16 {
  background: linear-gradient(
    45deg,
    #ff6b6b,
    #feca57,
    #48dbfb,
    #ff9ff3,
    #f368e0
  );
  background-size: 400% 400%;
  animation: gradientBG 5s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

.card-16 .card-icon {
  color: white;
}
.card-16 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 17 - حديث ==================== */
.card-17 {
  background: linear-gradient(135deg, #2c3e50, #3498db);
  color: white;
  border-radius: 30px;
}`,
  },
  18: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 18</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-18">
    <div class="card-icon"><i class="fas fa-award"></i></div>
    <h3>🏆 الجائزة الذهبية</h3>
    <p>حاصل على جائزة أفضل منتج لعام 2024</p>
    <button>شاهد الجائزة</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}

.card-15 .card-icon {
  transform: translateZ(30px);
}
.card-15 h3,
.card-15 p,
.card-15 button {
  transform: translateZ(20px);
}
.card-15 button {
  background: white;
  color: #fa709a;
}

/* ==================== CARD 16 - متدرج ==================== */
.card-16 {
  background: linear-gradient(
    45deg,
    #ff6b6b,
    #feca57,
    #48dbfb,
    #ff9ff3,
    #f368e0
  );
  background-size: 400% 400%;
  animation: gradientBG 5s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

.card-16 .card-icon {
  color: white;
}
.card-16 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 17 - حديث ==================== */
.card-17 {
  background: linear-gradient(135deg, #2c3e50, #3498db);
  color: white;
  border-radius: 30px;
}

.card-17 .card-icon {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.card-17 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #2c3e50;
}

/* ==================== CARD 18 - دائري كامل ==================== */
.card-18 {
  background: linear-gradient(145deg, #2d2d44, #1a1a2e);
  color: white;
  border-radius: 50%;
  width: 300px;
  height: 380px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
}`,
  },
  19: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 19</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-19">
    <div class="card-icon"><i class="fas fa-infinity"></i></div>
    <h3>♾️ غير محدود</h3>
    <p>استخدام غير محدود - اشترك مرة واستمتع للأبد</p>
    <button>ابدأ الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}

.card-15 .card-icon {
  transform: translateZ(30px);
}
.card-15 h3,
.card-15 p,
.card-15 button {
  transform: translateZ(20px);
}
.card-15 button {
  background: white;
  color: #fa709a;
}

/* ==================== CARD 16 - متدرج ==================== */
.card-16 {
  background: linear-gradient(
    45deg,
    #ff6b6b,
    #feca57,
    #48dbfb,
    #ff9ff3,
    #f368e0
  );
  background-size: 400% 400%;
  animation: gradientBG 5s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

.card-16 .card-icon {
  color: white;
}
.card-16 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 17 - حديث ==================== */
.card-17 {
  background: linear-gradient(135deg, #2c3e50, #3498db);
  color: white;
  border-radius: 30px;
}

.card-17 .card-icon {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.card-17 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #2c3e50;
}

/* ==================== CARD 18 - دائري كامل ==================== */
.card-18 {
  background: linear-gradient(145deg, #2d2d44, #1a1a2e);
  color: white;
  border-radius: 50%;
  width: 300px;
  height: 380px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
}

.card-18 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
}
.card-18 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1a1a2e;
}

/* ==================== CARD 19 - زجاجي ==================== */
.card-19 {
  background: linear-gradient(
    135deg,
    rgba(255, 255, 255, 0.1),
    rgba(255, 255, 255, 0.05)
  );
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  color: white;
}`,
  },
  20: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 20</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-20">
    <div class="card-content">
        <div class="card-icon"><i class="fas fa-sparkles"></i></div>
        <h3>🌟 لمسة سحرية</h3>
        <p>أضف لمسة سحرية لحياتك مع منتجاتنا الفريدة</p>
        <button>اطلب الآن</button>
    </div>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}

.card-15 .card-icon {
  transform: translateZ(30px);
}
.card-15 h3,
.card-15 p,
.card-15 button {
  transform: translateZ(20px);
}
.card-15 button {
  background: white;
  color: #fa709a;
}

/* ==================== CARD 16 - متدرج ==================== */
.card-16 {
  background: linear-gradient(
    45deg,
    #ff6b6b,
    #feca57,
    #48dbfb,
    #ff9ff3,
    #f368e0
  );
  background-size: 400% 400%;
  animation: gradientBG 5s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

.card-16 .card-icon {
  color: white;
}
.card-16 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 17 - حديث ==================== */
.card-17 {
  background: linear-gradient(135deg, #2c3e50, #3498db);
  color: white;
  border-radius: 30px;
}

.card-17 .card-icon {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.card-17 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #2c3e50;
}

/* ==================== CARD 18 - دائري كامل ==================== */
.card-18 {
  background: linear-gradient(145deg, #2d2d44, #1a1a2e);
  color: white;
  border-radius: 50%;
  width: 300px;
  height: 380px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
}

.card-18 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
}
.card-18 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1a1a2e;
}

/* ==================== CARD 19 - زجاجي ==================== */
.card-19 {
  background: linear-gradient(
    135deg,
    rgba(255, 255, 255, 0.1),
    rgba(255, 255, 255, 0.05)
  );
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  color: white;
}

.card-19 .card-icon {
  background: linear-gradient(135deg, #a855f7, #6366f1);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.card-19 button {
  background: linear-gradient(135deg, #a855f7, #6366f1);
  color: white;
}

/* ==================== CARD 20 - لمسة سحرية ==================== */
.card-20 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  position: relative;
  overflow: hidden;
}`,
  },
  21: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 21</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-21">
    <div class="card-icon"><i class="fas fa-water"></i></div>
    <h3>🌊 عمق الأناقة</h3>
    <p>تصميم فريد يجمع بين الأناقة والعملية</p>
    <button>استكشف الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* ==================== CARD 1 - بسيط أنيق ==================== */
.card-1 {
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  color: #333;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  margin-top: 40px;
}

.card-1 .card-icon {
  color: #4a90d9;
}
.card-1 button {
  background: linear-gradient(135deg, #4a90d9, #357abd);
  color: white;
}

/* ==================== CARD 2 - دائري مع حدود ==================== */
.card-2 {
  background: linear-gradient(145deg, #ff6b6b, #ee5a5a);
  color: white;
  border: 4px solid #fff;
  box-shadow: 0 15px 35px rgba(255, 107, 107, 0.4);
  margin-top: 40px;
}

.card-2 .card-icon {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-2 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 3 - زاوية مائلة ==================== */
.card-3 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  padding-bottom: 50px;
  margin-top: 40px;
}

.card-3 .card-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #ff6b6b;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
}

.card-3 .card-icon {
  color: #ffd700;
}
.card-3 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 4 - داكن مع توهج ==================== */
.card-4 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  box-shadow:
    0 0 30px rgba(255, 215, 0, 0.3),
    0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 215, 0, 0.3);
}

.card-4 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
}

.card-4 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 5 - شفاف ==================== */
.card-5 {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.card-5 .card-icon {
  color: #00d4aa;
}
.card-5 button {
  background: linear-gradient(135deg, #00d4aa, #00a885);
  color: white;
}

/* ==================== CARD 6 - مع شريط ==================== */
.card-6 {
  background: linear-gradient(145deg, #4ecdc4, #44a08d);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-6::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
}

.card-6 .card-icon {
  color: #2c3e50;
}
.card-6 button {
  background: white;
  color: #4ecdc4;
}

/* ==================== CARD 7 - إطار مزدوج ==================== */
.card-7 {
  background: linear-gradient(145deg, #a8edea, #fed6e3);
  color: #333;
  border: 3px solid transparent;
  background-clip: padding-box;
  position: relative;
}

.card-7::before {
  content: "";
  position: absolute;
  top: -3px;
  left: -3px;
  right: -3px;
  bottom: -3px;
  background: linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 23px;
  z-index: -1;
}

.card-7 .card-icon {
  color: #667eea;
}
.card-7 button {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ==================== CARD 8 - نيون ==================== */
.card-8 {
  background: #0d0d0d;
  color: white;
  box-shadow:
    0 0 20px rgba(0, 255, 255, 0.3),
    inset 0 0 20px rgba(0, 255, 255, 0.1);
  border: 1px solid rgba(0, 255, 255, 0.5);
}

.card-8 .card-icon {
  color: #00ffff;
  text-shadow:
    0 0 10px #00ffff,
    0 0 20px #00ffff;
  animation: neonPulse 2s infinite;
}

@keyframes neonPulse {
  0%,
  100% {
    text-shadow:
      0 0 10px #00ffff,
      0 0 20px #00ffff;
  }
  50% {
    text-shadow:
      0 0 20px #00ffff,
      0 0 40px #00ffff,
      0 0 60px #00ffff;
  }
}

.card-8 button {
  background: transparent;
  color: #00ffff;
  border: 2px solid #00ffff;
}

.card-8 button:hover {
  background: #00ffff;
  color: #0d0d0d;
}

/* ==================== CARD 9 - طبقي ==================== */
.card-9 {
  background: transparent;
  padding: 0;
  color: white;
  overflow: hidden;
}

.card-9 .card-top {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  padding: 30px;
  clip-path: polygon(0 0, 100% 0, 100% 80%, 50% 100%, 0 80%);
  padding-bottom: 50px;
}

.card-9 .card-bottom {
  background: linear-gradient(135deg, #2d2d44, #1a1a2e);
  padding: 30px;
  margin-top: -30px;
}

.card-9 .card-icon {
  color: white;
}
.card-9 button {
  background: linear-gradient(135deg, #ff9a56, #ff6b6b);
  color: white;
}

/* ==================== CARD 10 - صورة كاملة ==================== */
.card-10 {
  background: linear-gradient(
    rgba(102, 126, 234, 0.9),
    rgba(118, 75, 162, 0.9)
  );
  color: white;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
}

.card-10 .card-icon {
  color: #ffd700;
}
.card-10 button {
  background: white;
  color: #667eea;
}

/* ==================== CARD 11 - خطافي ==================== */
.card-11 {
  background: linear-gradient(145deg, #11998e, #38ef7d);
  color: white;
  clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
}

.card-11 .card-icon {
  color: #ffd700;
}
.card-11 button {
  background: white;
  color: #11998e;
}

/* ==================== CARD 12 - موسمي ==================== */
.card-12 {
  background: linear-gradient(135deg, #00c6fb, #005bea);
  color: white;
  position: relative;
}

.card-12::before {
  content: "❄️";
  position: absolute;
  font-size: 100px;
  opacity: 0.1;
  top: -20px;
  right: -20px;
}

.card-12 .card-icon {
  color: #e0f7ff;
}
.card-12 button {
  background: white;
  color: #005bea;
}

/* ==================== CARD 13 - تفاعلي ==================== */
.card-13 {
  background: linear-gradient(145deg, #f093fb, #f5576c);
  color: white;
}

.card-13 .card-icon {
  background: rgba(255, 255, 255, 0.2);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.card-13 button {
  background: white;
  color: #f5576c;
}

/* ==================== CARD 14 - عائم ==================== */
.card-14 {
  background: linear-gradient(145deg, #4facfe, #00f2fe);
  color: white;
  box-shadow: 0 20px 40px rgba(79, 172, 254, 0.4);
  border-bottom: 5px solid rgba(255, 255, 255, 0.3);
}

.card-14 .card-icon {
  color: white;
}
.card-14 button {
  background: white;
  color: #4facfe;
}

/* ==================== CARD 15 - ثلاثي الأبعاد ==================== */
.card-15 {
  background: linear-gradient(145deg, #fa709a, #fee140);
  color: white;
  transform-style: preserve-3d;
  perspective: 1000px;
}

.card-15 .card-icon {
  transform: translateZ(30px);
}
.card-15 h3,
.card-15 p,
.card-15 button {
  transform: translateZ(20px);
}
.card-15 button {
  background: white;
  color: #fa709a;
}

/* ==================== CARD 16 - متدرج ==================== */
.card-16 {
  background: linear-gradient(
    45deg,
    #ff6b6b,
    #feca57,
    #48dbfb,
    #ff9ff3,
    #f368e0
  );
  background-size: 400% 400%;
  animation: gradientBG 5s ease infinite;
  color: white;
}

@keyframes gradientBG {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

.card-16 .card-icon {
  color: white;
}
.card-16 button {
  background: white;
  color: #ff6b6b;
}

/* ==================== CARD 17 - حديث ==================== */
.card-17 {
  background: linear-gradient(135deg, #2c3e50, #3498db);
  color: white;
  border-radius: 30px;
}

.card-17 .card-icon {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.card-17 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #2c3e50;
}

/* ==================== CARD 18 - دائري كامل ==================== */
.card-18 {
  background: linear-gradient(145deg, #2d2d44, #1a1a2e);
  color: white;
  border-radius: 50%;
  width: 300px;
  height: 380px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
}

.card-18 .card-icon {
  color: #ffd700;
  text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
}
.card-18 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1a1a2e;
}

/* ==================== CARD 19 - زجاجي ==================== */
.card-19 {
  background: linear-gradient(
    135deg,
    rgba(255, 255, 255, 0.1),
    rgba(255, 255, 255, 0.05)
  );
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  color: white;
}

.card-19 .card-icon {
  background: linear-gradient(135deg, #a855f7, #6366f1);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.card-19 button {
  background: linear-gradient(135deg, #a855f7, #6366f1);
  color: white;
}

/* ==================== CARD 20 - لمسة سحرية ==================== */
.card-20 {
  background: linear-gradient(145deg, #1e1e2f, #2d2d44);
  color: white;
  position: relative;
  overflow: hidden;
}

.card-20::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: conic-gradient(
    from 0deg,
    transparent,
    #ffd700,
    transparent,
    #ffd700,
    transparent
  );
  animation: rotate 4s linear infinite;
  opacity: 0.3;
}

@keyframes rotate {
  100% {
    transform: rotate(360deg);
  }
}

.card-20 .card-content {
  position: relative;
  z-index: 1;
}

.card-20 .card-icon {
  color: #ffd700;
  animation: sparkle 2s infinite;
}

@keyframes sparkle {
  0%,
  100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.7;
    transform: scale(1.1);
  }
}

.card-20 button {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #1e1e2f;
}

/* ==================== CARD 21-40 ==================== */
.card-21 {
  background: linear-gradient(145deg, #0c2647, #1a3a5c);
  color: white;
  border: 2px solid #1e90ff;
}`,
  },
  22: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 22</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-22">
    <div class="card-icon"><i class="fas fa-sun"></i></div>
    <h3>☀️ يوم مشع</h3>
    <p>أضف إشراقة يوم جديد مع منتجاتنا المميزة</p>
    <button>اعرف المزيد</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-22 {
  background: linear-gradient(135deg, #ff7e5f, #feb47b);
  color: white;
  box-shadow: 0 15px 35px rgba(255, 126, 95, 0.4);
}`,
  },
  23: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 23</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-23">
    <div class="card-icon"><i class="fas fa-dragon"></i></div>
    <h3>🐉 قوة الخضرة</h3>
    <p>منتجات خضراء ذات جودة استثنائية</p>
    <button>اطلب الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-23 {
  background: linear-gradient(135deg, #134e5e, #71b280);
  color: white;
}`,
  },
  24: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 24</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-24">
    <div class="card-icon"><i class="fas fa-chess-king"></i></div>
    <h3>♚ الملكي</h3>
    <p>منتجات حصرية للطبقة المميزة</p>
    <button>انضم للصفوة</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-24 {
  background: linear-gradient(135deg, #4b134f, #c94b4b);
  color: white;
}`,
  },
  25: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 25</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-25">
    <div class="card-icon"><i class="fas fa-heartbeat"></i></div>
    <h3>💗 حب الحياة</h3>
    <p>منتجات ملهمة تجعلك تحب حياتك أكثر</p>
    <button>اكتشف الحب</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-25 {
  background: linear-gradient(135deg, #ee9ca7, #ffdde1);
  color: #333;
}`,
  },
  26: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 26</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-26">
    <div class="card-icon"><i class="fas fa-city"></i></div>
    <h3>🏙️ أناقة المدينة</h3>
    <p>تصميم عصري يناسب أذواق المدينة</p>
    <button>تصفح الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-26 {
  background: linear-gradient(135deg, #2c3e50, #4ca1af);
  color: white;
}`,
  },
  27: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 27</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-27">
    <div class="card-icon"><i class="fas fa-suitcase"></i></div>
    <h3>💼 كنز ثمين</h3>
    <p>منتجات ثمينة تستحق كل ريال</p>
    <button>احصل على الكنز</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-27 {
  background: linear-gradient(135deg, #b8860b, #ffd700);
  color: #1a1a1a;
}`,
  },
  28: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 28</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-28">
    <div class="card-icon"><i class="fas fa-meteor"></i></div>
    <h3>☄️ لمعان الفضاء</h3>
    <p>تألق مع منتجاتنا الفضية المميزة</p>
    <button>أطلق العنان</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-28 {
  background: linear-gradient(135deg, #e0e0e0, #f5f5f5, #e0e0e0);
  color: #333;
  border: 3px solid #c0c0c0;
}`,
  },
  29: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 29</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-29">
    <div class="card-icon"><i class="fas fa-dragon"></i></div>
    <h3>🐲 قوة التنين</h3>
    <p>منتجات قوية كقوة التنين</p>
    <button>اشعر بالقوة</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-29 {
  background: linear-gradient(135deg, #800000, #8b0000);
  color: white;
}`,
  },
  30: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 30</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-30">
    <div class="card-icon"><i class="fas fa-cloud-sun"></i></div>
    <h3>☁️ يوم غائم</h3>
    <p>برودة الجو مع منتجاتنا المنعشة</p>
    <button>استمتع بالبرد</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-30 {
  background: linear-gradient(135deg, #87ceeb, #4682b4);
  color: white;
}`,
  },
  31: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 31</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-31">
    <div class="card-icon"><i class="fas fa-mug-hot"></i></div>
    <h3>☕ دفء القهوة</h3>
    <p>شعور دافئ مع منتجاتنا المميزة</p>
    <button>استمتع بالدفء</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-31 {
  background: linear-gradient(135deg, #8b4513, #d2691e);
  color: white;
}`,
  },
  32: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 32</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-32">
    <div class="card-icon"><i class="fas fa-lightbulb"></i></div>
    <h3>💡 فكرة مشرقة</h3>
    <p>أفكار مبتكرة تنير طريقك</p>
    <button>أضاء فكرتك</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-32 {
  background: linear-gradient(135deg, #ffd700, #ffaa00);
  color: #333;
}`,
  },
  33: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 33</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-33">
    <div class="card-icon"><i class="fas fa-hat-wizard"></i></div>
    <h3>🧙 سحر السحرة</h3>
    <p>منتجات سحرية ستأخذ أنفاسك</p>
    <button>جرب السحر</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-33 {
  background: linear-gradient(135deg, #4b0082, #8b008b);
  color: white;
}`,
  },
  34: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 34</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-34">
    <div class="card-icon"><i class="fas fa-coffee"></i></div>
    <h3>🫖 وقت الشاي</h3>
    <p>استرخِ واستمتع بلحظات هادئة</p>
    <button>استمتع الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-34 {
  background: linear-gradient(135deg, #d4a574, #8b7355);
  color: white;
}`,
  },
  35: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 35</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-35">
    <div class="card-icon"><i class="fas fa-fish"></i></div>
    <h3>🪸 شاطئ المرجان</h3>
    <p>انعم بجمال البحار مع منتجاتنا</p>
    <button>الغوص الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-35 {
  background: linear-gradient(135deg, #ff7f50, #ff6347);
  color: white;
}`,
  },
  36: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 36</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-36">
    <div class="card-icon"><i class="fas fa-spa"></i></div>
    <h3>💆 لحظة استرخاء</h3>
    <p>منتجات العناية التي تستحقها</p>
    <button>اهتم بنفسك</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-36 {
  background: linear-gradient(135deg, #e6e6fa, #dda0dd);
  color: #333;
}`,
  },
  37: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 37</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-37">
    <div class="card-icon"><i class="fas fa-moon"></i></div>
    <h3>🌙 ضوء القمر</h3>
    <p>أناقة الليل في أحلى صورها</p>
    <button>استمتع بالليل</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-37 {
  background: linear-gradient(135deg, #2d1b4e, #4a0e4e);
  color: white;
}`,
  },
  38: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 38</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-38">
    <div class="card-icon"><i class="fas fa-umbrella-beach"></i></div>
    <h3>🏖️ اجازة الأحلام</h3>
    <p>منتجات العطلة التي تحتاجها</p>
    <button>احجز الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-38 {
  background: linear-gradient(135deg, #40e0d0, #20b2aa);
  color: white;
}`,
  },
  39: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 39</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-39">
    <div class="card-icon"><i class="fas fa-fish"></i></div>
    <h3>🐠 بحر الحياة</h3>
    <p>عالم من الخيارات تحت البحار</p>
    <button>استكشف البحار</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-39 {
  background: linear-gradient(135deg, #1e90ff, #00ced1);
  color: white;
}`,
  },
  40: {
    html: `<!-- Complete HTML Template -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card 40</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card card-40">
    <div class="card-icon"><i class="fas fa-gift"></i></div>
    <h3>🎉 نهاية سعيدة</h3>
    <p>اختتم تجربتك بأفضل شكل</p>
    <button>احتفل الآن</button>
</div>

</body>
</html>`,
    css: `.card {
    width: 350px;
    height: auto;
    min-height: 320px;
    padding: 35px 30px;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s ease;
    font-family: 'Cairo', sans-serif;
    margin: 20px;
    position: relative;
    overflow: hidden;
}
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.card-icon {
    font-size: 50px;
    margin-bottom: 20px;
}
.card h3 {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 700;
}
.card p {
    font-size: 16px;
    line-height: 1.8;
    margin-bottom: 25px;
    opacity: 0.9;
}
.card button {
    padding: 14px 35px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Cairo', sans-serif;
    transition: all 0.3s ease;
}
.card button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.card-40 {
  background: linear-gradient(135deg, #ff1493, #ff69b4);
  color: white;
  position: relative;
  overflow: hidden;
}`,
  },
};

// Function to show code modal
function showCode(cardNumber) {
  const modal = document.getElementById("codeModal");
  const htmlCode = document.getElementById("htmlCode");
  const cssCode = document.getElementById("cssCode");
  const modalTitle = document.getElementById("modalTitle");

  const data = cardData[cardNumber] || cardData[1];

  modalTitle.textContent = `Card ${cardNumber} - Full Code (Width: 350px, Height: auto)`;
  htmlCode.textContent = data.html;
  cssCode.textContent = data.css;

  // Syntax highlighting
  document.getElementById("htmlCode").className = "language-html";
  if (document.getElementById("cssCode"))  document.getElementById("cssCode").className  = "language-css";
  if (document.getElementById("jsCode"))   document.getElementById("jsCode").className   = "language-javascript";
  modal.style.display = "flex";
  if (window.Prism) setTimeout(() => Prism.highlightAll(), 50);
}

// Function to close modal
function closeModal() {
  const modal = document.getElementById("codeModal");
  modal.style.display = "none";
}

// Function to copy code to clipboard
function copyToClipboard(elementId, btn) {
  const text = document.getElementById(elementId).textContent;
  navigator.clipboard
    .writeText(text)
    .then(() => {
      if (!btn) return;
      const originalText = btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
      btn.style.background = "#4caf50";

      setTimeout(() => {
        btn.innerHTML = originalText;
        btn.style.background = "";
      }, 2000);
    })
    .catch((err) => {
      console.error("Failed to copy: ", err);
    });
}

// Close modal when clicking outside
window.onclick = function (event) {
  const modal = document.getElementById("codeModal");
  if (event.target == modal) {
    closeModal();
  }
};

// Mobile Menu Toggle
document.addEventListener("DOMContentLoaded", function () {
  const menuBtn = document.querySelector(".menu-btn");
  const navLinks = document.querySelector(".nav-links");

  if (menuBtn && navLinks) {
    menuBtn.addEventListener("click", function () {
      navLinks.classList.toggle("active");
    });

    // Close menu when clicking on a link
    const links = navLinks.querySelectorAll("a");
    links.forEach((link) => {
      link.addEventListener("click", function () {
        navLinks.classList.remove("active");
      });
    });

    // Close menu when clicking outside
    document.addEventListener("click", function (event) {
      if (!menuBtn.contains(event.target) && !navLinks.contains(event.target)) {
        navLinks.classList.remove("active");
      }
    });
  }
});

// Category Filter for Cards
document.addEventListener("DOMContentLoaded", function () {
  const filterBtns = document.querySelectorAll(".category-btn");
  const noResults = document.getElementById("noResults");
  if (!filterBtns.length) return;

  filterBtns.forEach((btn) => {
    btn.addEventListener("click", function () {
      const category = this.getAttribute("data-category");

      filterBtns.forEach((b) => b.classList.remove("active"));
      this.classList.add("active");

      const cards = document.querySelectorAll(".card");
      let visibleCount = 0;

      cards.forEach((card) => {
        const matches =
          category === "all" || card.getAttribute("data-category") === category;
        card.style.display = matches ? "block" : "none";
        if (matches) visibleCount++;
      });

      if (noResults) {
        noResults.style.display = visibleCount === 0 ? "block" : "none";
      }
    });
  });
});
