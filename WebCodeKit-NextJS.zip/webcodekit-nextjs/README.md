# WebCodeKit — Next.js

Full-stack migration of WebCodeKit from Express.js to **Next.js 15** (App Router).

## Stack

| Layer | Tech |
|---|---|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript |
| Backend | Next.js API Route Handlers (replaces Express) |
| AI | Anthropic Claude (claude-sonnet-4-6) |
| Styling | Existing CSS files (served from `/public/css/`) |
| Frontend JS | Existing vanilla JS (served from `/public/js/`) |

---

## Project Structure

```
webcodekit-nextjs/
├── src/
│   ├── app/
│   │   ├── layout.tsx            # Root layout — shared head, fonts, scripts
│   │   ├── page.tsx              # / (Home)
│   │   ├── globals.css           # Imports all CSS in correct order
│   │   ├── not-found.tsx         # /404
│   │   ├── sitemap.ts            # Auto-generates /sitemap.xml
│   │   ├── robots.ts             # Auto-generates /robots.txt
│   │   │
│   │   ├── buttons/page.tsx      # /buttons
│   │   ├── cards/page.tsx        # /cards
│   │   ├── forms/page.tsx        # /forms
│   │   ├── systems/page.tsx      # /systems
│   │   ├── kits/page.tsx         # /kits
│   │   ├── smart-ai/page.tsx     # /smart-ai  ← full RSC shell
│   │   ├── favorites/page.tsx    # /favorites
│   │   └── about/page.tsx        # /about
│   │
│   │   └── api/
│   │       ├── chat/route.ts     # POST /api/chat   — replaces Express /api/chat
│   │       ├── code/route.ts     # POST /api/code   — replaces Express /api/code
│   │       ├── vision/route.ts   # POST /api/vision — replaces Express /api/vision
│   │       └── health/route.ts   # GET  /api/health — replaces Express /api/health
│   │
│   ├── components/
│   │   └── Navbar.tsx            # Shared React navbar component
│   │
│   └── lib/
│       ├── anthropic.ts          # Anthropic API client + system prompts
│       ├── rateLimit.ts          # In-memory rate limiter (swap with Redis for prod)
│       └── cors.ts               # CORS helpers for API routes
│
├── public/
│   ├── css/                      # All existing CSS files (unchanged)
│   ├── js/                       # All existing JS files (unchanged)
│   ├── icons/                    # PWA icons
│   ├── og-preview.png
│   ├── favicon.svg
│   ├── favicon.ico
│   └── manifest.json
│
├── .env.local.example            # Copy to .env.local and fill in
├── next.config.mjs
├── tsconfig.json
└── package.json
```

---

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.local.example .env.local
# Edit .env.local and add your ANTHROPIC_API_KEY
```

### 3. Copy existing assets to /public
```bash
# Copy all CSS files
cp path/to/old-project/*.css public/css/

# Copy all JS files (except server.js)
cp path/to/old-project/*.js public/js/

# Copy images and icons
cp path/to/old-project/og-preview.png public/
cp path/to/old-project/favicon.* public/
cp -r path/to/old-project/icons public/
cp path/to/old-project/manifest.json public/
```

### 4. Run development server
```bash
npm run dev
# → http://localhost:3000
```

### 5. Build for production
```bash
npm run build
npm start
```

---

## API Endpoints

All endpoints are Next.js API Route Handlers under `src/app/api/`.

### `POST /api/chat`
Chat with the AI assistant.

**Request:**
```json
{
  "message": "How do I center a div in CSS?",
  "history": []
}
```

**Response:**
```json
{ "reply": "You can center a div using..." }
```

---

### `POST /api/code`
Generate a complete UI component.

**Request:**
```json
{
  "prompt": "Create a dark login form with gradient button",
  "history": []
}
```

**Response:**
```json
{
  "html": "<div class=\"wck-login\">...</div>",
  "css":  ".wck-login { ... }",
  "js":   "",
  "name": "Dark Login Form"
}
```

---

### `POST /api/vision`
Convert a design image to code.

**Request:**
```json
{
  "imageBase64": "data:image/png;base64,...",
  "imageType":   "image/png",
  "prompt":      "Convert this design to HTML and CSS"
}
```

**Response:** same shape as `/api/code`.

---

### `GET /api/health`
Health check — safe to call publicly.

**Response:**
```json
{
  "status":    "ok",
  "model":     "claude-sonnet-4-6",
  "apiReady":  true,
  "timestamp": "2025-07-01T10:00:00.000Z"
}
```

---

## Frontend Changes

The frontend JS files (`smart-ai.js`, `buttons.js`, etc.) remain as vanilla JS but need one small update — change `backendUrl` to point to the Next.js API:

```js
// In smart-ai.js — line ~14
const AI_CONFIG = {
  useAPI:     true,
  backendUrl: "",   // ← keep empty string; Next.js serves API on same origin
  apiKey:     sessionStorage.getItem("wck_api_key") || "",
};
```

Since Next.js serves both frontend and API on the same origin, `backendUrl: ""` means `/api/chat`, `/api/code`, and `/api/vision` resolve correctly with no CORS issues in production.

---

## Rate Limiting

The built-in rate limiter (`src/lib/rateLimit.ts`) stores state **in memory**.

- Works correctly on a single Node.js process (Vercel serverless + single region)
- For multi-region or high traffic: replace with [Upstash Redis](https://upstash.com/) — the `isRateLimited()` interface is identical

---

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ Yes | — | Your Anthropic API key |
| `ANTHROPIC_MODEL` | No | `claude-sonnet-4-6` | Claude model to use |
| `RATE_LIMIT_RPM` | No | `30` | Max requests per minute per IP |
| `ALLOWED_ORIGIN` | No | `*` | CORS allowed origin |
| `NEXT_PUBLIC_SITE_URL` | No | `https://webcodekit.dev` | Public URL (used in sitemap & OG) |

---

## Deployment

### Vercel (recommended)
```bash
npx vercel
# Set ANTHROPIC_API_KEY in Vercel dashboard → Settings → Environment Variables
```

### Docker
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm ci && npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

---

## Key Differences vs Old Express Server

| Feature | Express (old) | Next.js (new) |
|---|---|---|
| Server file | `server.js` | `src/app/api/*/route.ts` |
| Static files | `express.static(__dirname)` | `/public` folder (built-in) |
| Rate limiting | `express-rate-limit` | `src/lib/rateLimit.ts` |
| CORS | `cors` package | `src/lib/cors.ts` |
| Start command | `node server.js` | `next start` |
| Dev command | `node --watch server.js` | `next dev` |
| TypeScript | ❌ None | ✅ Full |
| SEO | Manual `<meta>` tags | Next.js `Metadata` API |
| Sitemap | Manual `sitemap.xml` | Auto-generated `app/sitemap.ts` |
| Robots | Manual `robots.txt` | Auto-generated `app/robots.ts` |
