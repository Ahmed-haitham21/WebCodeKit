/**
 * app/layout.tsx
 * Root layout — wraps every page with shared <head>, fonts, and theme init.
 */
import type { Metadata, Viewport } from "next";
import Script from "next/script";
import "./globals.css";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://webcodekit.dev";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "WebCodeKit — Free Ready-Made UI Components Library",
    template: "%s | WebCodeKit",
  },
  description:
    "WebCodeKit is a free UI component library with 100+ buttons, 40 cards, 24 forms, and ready-made systems you can copy and use in your web projects instantly.",
  keywords: ["UI components", "HTML CSS", "web development", "frontend", "free components"],
  authors: [{ name: "WebCodeKit" }],
  creator: "WebCodeKit",
  openGraph: {
    type:        "website",
    siteName:    "WebCodeKit",
    url:         SITE_URL,
    images:      [{ url: "/og-preview.png", width: 1200, height: 630 }],
  },
  twitter: {
    card:   "summary_large_image",
    images: ["/og-preview.png"],
  },
  manifest: "/manifest.json",
  icons: {
    icon:  [{ url: "/favicon.svg", type: "image/svg+xml" }, { url: "/favicon.ico" }],
    apple: "/icons/icon-192.png",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width:             "device-width",
  initialScale:      1,
  themeColor:        "#667eea",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Font Awesome */}
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          crossOrigin="anonymous"
        />
        {/* Apply saved theme before first paint to avoid flash */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){var t=localStorage.getItem("theme")||"dark";document.documentElement.setAttribute("data-theme",t);})();`,
          }}
        />
      </head>
      <body>
        {children}

        {/* Global scripts loaded once for all pages */}
        <Script src="/js/theme-toggle.js"     strategy="afterInteractive" />
        <Script src="/js/navbar.js"           strategy="afterInteractive" />
        <Script src="/js/search.js"           strategy="afterInteractive" />
        <Script src="/js/favorites.js"        strategy="afterInteractive" />
        <Script src="/js/rating.js"           strategy="afterInteractive" />
        <Script src="/js/color-customizer.js" strategy="afterInteractive" />
        <Script src="/js/lang.js"             strategy="afterInteractive" />
        <Script src="/js/utils.js"            strategy="afterInteractive" />
      </body>
    </html>
  );
}
