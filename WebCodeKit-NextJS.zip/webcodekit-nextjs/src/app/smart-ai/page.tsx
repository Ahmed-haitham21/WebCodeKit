/**
 * app/smart-ai/page.tsx  →  /smart-ai
 * AI Assistant page.
 * All interactivity lives in /public/js/smart-ai.js — this component
 * just renders the shell HTML and the script tag.
 */
import type { Metadata } from "next";
import Script from "next/script";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title:       "AI Assistant",
  description: "Use the WebCodeKit AI Assistant to generate professional UI components instantly with just a text prompt or an image.",
  alternates:  { canonical: "/smart-ai" },
  openGraph:   { url: "/smart-ai" },
};

export default function SmartAiPage() {
  return (
    <>
      <Navbar />

      <main className="ai-page" id="aiPage">
        {/* ── Hero ── */}
        <section className="ai-hero-section">
          <div className="ai-hero-badge">
            <i className="fas fa-wand-magic-sparkles" aria-hidden="true" /> Powered by Claude AI
          </div>
          <h1 className="ai-hero-title">
            Generate UI Components<br />
            <span className="ai-hero-accent">Instantly with AI</span>
          </h1>
          <p className="ai-hero-subtitle">
            Describe what you need or upload a design image — get production-ready HTML, CSS &amp; JS in seconds.
          </p>
        </section>

        {/* ── Chat wrapper ── */}
        <div className="ai-chat-wrapper">
          <div className="ai-input-card" id="aiInputCard">

            {/* Mode tabs */}
            <div className="ai-mode-tabs" role="tablist" aria-label="AI mode">
              <button className="ai-mode-tab active" data-mode="chat" role="tab" aria-selected="true">
                <i className="fas fa-comments" aria-hidden="true" /> Chat
              </button>
              <button className="ai-mode-tab" data-mode="code" role="tab" aria-selected="false">
                <i className="fas fa-code" aria-hidden="true" /> Generate Component
              </button>
              <button className="ai-mode-tab" data-mode="vision" role="tab" aria-selected="false">
                <i className="fas fa-eye" aria-hidden="true" /> Design to Code
              </button>
            </div>

            {/* Quick-prompt chips */}
            <div className="ai-chips" aria-label="Quick prompts">
              <button className="ai-chip" data-prompt="Create a modern login form">Login Form</button>
              <button className="ai-chip" data-prompt="Generate a pricing card with 3 tiers">Pricing Card</button>
              <button className="ai-chip" data-prompt="Build a responsive navbar">Navbar</button>
              <button className="ai-chip" data-prompt="Create an animated button">Button</button>
              <button className="ai-chip" data-prompt="Generate a dark dashboard stat card">Stat Card</button>
            </div>

            {/* Chat messages */}
            <div className="ai-chat-messages" id="aiChatMessages" aria-live="polite" aria-label="Conversation">
              <div className="ai-message ai-message--bot">
                <div className="ai-message-avatar"><i className="fas fa-wand-magic-sparkles" aria-hidden="true" /></div>
                <div className="ai-message-content">
                  <p>Hello! I&apos;m your WebCodeKit AI assistant. I can help you:</p>
                  <ul>
                    <li>Answer questions about HTML, CSS &amp; JavaScript</li>
                    <li>Generate complete UI components from a description</li>
                    <li>Convert a design image into code</li>
                  </ul>
                  <p>What would you like to build today?</p>
                </div>
              </div>
            </div>

            {/* Vision upload area */}
            <div className="ai-vision-drop" id="aiVisionDrop" style={{ display: "none" }} aria-label="Image upload area">
              <i className="fas fa-cloud-upload-alt" aria-hidden="true" />
              <p>Drag &amp; drop a design image, or <label htmlFor="visionFileInput" className="vision-browse-link">browse</label></p>
              <input type="file" id="visionFileInput" accept="image/*" className="sr-only" />
            </div>

            {/* Input row */}
            <div className="ai-input-row">
              <button className="ai-vision-btn" id="aiVisionBtn" title="Upload a design image" aria-label="Upload image">
                <i className="fas fa-image" aria-hidden="true" />
              </button>
              <textarea
                className="ai-input"
                id="aiInput"
                placeholder="Describe the component you want to generate…"
                rows={1}
                aria-label="AI prompt input"
              />
              <button className="ai-send-btn" id="aiSendBtn" aria-label="Send message">
                <i className="fas fa-paper-plane" aria-hidden="true" />
              </button>
            </div>
          </div>

          {/* Component preview panel — shown after code generation */}
          <div className="ai-preview-panel" id="aiPreviewPanel" style={{ display: "none" }}>
            <div className="ai-preview-header">
              <h2 className="ai-preview-title" id="aiPreviewTitle">Generated Component</h2>
              <div className="ai-preview-actions">
                <button className="ai-preview-btn" id="aiCopyHtml" title="Copy HTML"><i className="fas fa-code" aria-hidden="true" /> HTML</button>
                <button className="ai-preview-btn" id="aiCopyCss"  title="Copy CSS"><i className="fas fa-paint-brush" aria-hidden="true" /> CSS</button>
                <button className="ai-preview-btn" id="aiCopyJs"   title="Copy JS"><i className="fas fa-bolt" aria-hidden="true" /> JS</button>
                <button className="ai-preview-btn ai-preview-btn--primary" id="aiSaveToFav" title="Save to favorites">
                  <i className="far fa-heart" aria-hidden="true" /> Save
                </button>
              </div>
            </div>
            <iframe
              id="aiPreviewFrame"
              className="ai-preview-frame"
              title="Component Preview"
              sandbox="allow-scripts"
            />
          </div>
        </div>
      </main>

      {/* Page-specific JS — must load AFTER the DOM is ready */}
      <Script src="/js/smart-ai.js" strategy="afterInteractive" />
    </>
  );
}
