/**
 * app/page.tsx  →  /
 * Homepage — Server Component.
 * The heavy interactive JS (slider, previews) is loaded
 * as a client-side script from /public/js/home.js.
 */
import type { Metadata } from "next";
import Script from "next/script";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "WebCodeKit — Free Ready-Made UI Components Library",
  description:
    "Free, ready-to-use UI components — buttons, cards, forms, and systems to accelerate your web development.",
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <Navbar />

      {/* ── Hero ── */}
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-content">
          <h1 id="hero-title" className="hero-title">
            Build Faster <span>With Ready UI</span>
          </h1>
          <p className="hero-subtitle">
            Free, copy-paste UI components for your next web project.
            100+ Buttons · 40 Cards · 24 Forms · Systems · Kits · AI
          </p>

          <div className="hero-stats" aria-label="Library statistics">
            <div className="hero-stat">
              <span className="hero-stat-num">100+</span>
              <span className="hero-stat-label">Buttons</span>
            </div>
            <div className="hero-stat">
              <span className="hero-stat-num">40</span>
              <span className="hero-stat-label">Cards</span>
            </div>
            <div className="hero-stat">
              <span className="hero-stat-num">24</span>
              <span className="hero-stat-label">Forms</span>
            </div>
            <div className="hero-stat">
              <span className="hero-stat-num">AI</span>
              <span className="hero-stat-label">Assistant</span>
            </div>
          </div>

          <div className="hero-actions">
            <a href="/buttons" className="hero-btn-primary">
              <i className="fas fa-rocket" aria-hidden="true" /> Browse Components
            </a>
            <a href="/smart-ai" className="hero-btn-secondary">
              <i className="fas fa-wand-magic-sparkles" aria-hidden="true" /> Try AI
            </a>
          </div>
        </div>
      </section>

      {/* ── Components Section ── */}
      <section className="components" aria-labelledby="components-title">
        <div className="container">
          <h2 id="components-title" className="components-title">
            Explore Components
          </h2>
          <p className="components-desc">
            Browse modern UI components ready to use in your projects. Buttons,
            cards, forms, systems, kits, and our AI assistant.
          </p>

          {/* Slider / preview grid — powered by home.js */}
          <div className="components-grid" id="componentsGrid">
            {/* Buttons box */}
            <div
              className="component-box"
              role="button"
              tabIndex={0}
              aria-label="Browse Buttons"
              onClick={() => { window.location.href = "/buttons"; }}
              onKeyDown={(e) => e.key === "Enter" && (window.location.href = "/buttons")}
            >
              <h3>Buttons</h3>
              <div className="slider-wrapper" id="buttonSlider">
                <button className="arrow" aria-label="Previous button" onClick={(e) => { e.stopPropagation(); if (typeof window !== 'undefined' && (window as unknown as Record<string, () => void>).prevButton) (window as unknown as Record<string, () => void>).prevButton(); }}>&#10094;</button>
                <div className="slider" id="buttonPreview" aria-live="polite" aria-label="Button preview" />
                <button className="arrow" aria-label="Next button" onClick={(e) => { e.stopPropagation(); if (typeof window !== 'undefined' && (window as unknown as Record<string, () => void>).nextButton) (window as unknown as Record<string, () => void>).nextButton(); }}>&#10095;</button>
              </div>
            </div>

            {/* Cards box */}
            <div
              className="component-box"
              role="button"
              tabIndex={0}
              aria-label="Browse Cards"
              onClick={() => { window.location.href = "/cards"; }}
              onKeyDown={(e) => e.key === "Enter" && (window.location.href = "/cards")}
            >
              <h3>Cards</h3>
              <div className="slider-wrapper" id="cardSlider">
                <button className="arrow" aria-label="Previous card" onClick={(e) => { e.stopPropagation(); if (typeof window !== 'undefined' && (window as unknown as Record<string, () => void>).prevCard) (window as unknown as Record<string, () => void>).prevCard(); }}>&#10094;</button>
                <div className="slider" id="cardPreview" aria-live="polite" aria-label="Card preview" />
                <button className="arrow" aria-label="Next card" onClick={(e) => { e.stopPropagation(); if (typeof window !== 'undefined' && (window as unknown as Record<string, () => void>).nextCard) (window as unknown as Record<string, () => void>).nextCard(); }}>&#10095;</button>
              </div>
            </div>

            {/* Forms box */}
            <div
              className="component-box"
              role="button"
              tabIndex={0}
              aria-label="Browse Forms"
              onClick={() => { window.location.href = "/forms"; }}
              onKeyDown={(e) => e.key === "Enter" && (window.location.href = "/forms")}
            >
              <h3>Forms</h3>
              <div className="slider-wrapper" id="formSlider">
                <button className="arrow" aria-label="Previous form" onClick={(e) => { e.stopPropagation(); if (typeof window !== 'undefined' && (window as unknown as Record<string, () => void>).prevform) (window as unknown as Record<string, () => void>).prevform(); }}>&#10094;</button>
                <div className="slider" id="formPreview" aria-live="polite" aria-label="Form preview" />
                <button className="arrow" aria-label="Next form" onClick={(e) => { e.stopPropagation(); if (typeof window !== 'undefined' && (window as unknown as Record<string, () => void>).nextform) (window as unknown as Record<string, () => void>).nextform(); }}>&#10095;</button>
              </div>
            </div>

            {/* Kits box */}
            <div
              className="component-box"
              role="button"
              tabIndex={0}
              aria-label="Browse Kits"
              onClick={() => { window.location.href = "/kits"; }}
              onKeyDown={(e) => e.key === "Enter" && (window.location.href = "/kits")}
            >
              <h3>Kits</h3>
              <div className="kits-static-preview">
                <div className="kit-preview-card"><span className="kit-preview-icon">🎨</span><span className="kit-preview-label">UI Kit</span></div>
                <div className="kit-preview-card"><span className="kit-preview-icon">⚡</span><span className="kit-preview-label">Quick Kit</span></div>
                <div className="kit-preview-card"><span className="kit-preview-icon">🚀</span><span className="kit-preview-label">Pro Kit</span></div>
              </div>
            </div>

            {/* AI box */}
            <div
              className="component-box component-box--ai"
              role="button"
              tabIndex={0}
              aria-label="Open AI Assistant"
              onClick={() => { window.location.href = "/smart-ai"; }}
              onKeyDown={(e) => e.key === "Enter" && (window.location.href = "/smart-ai")}
            >
              <h3>AI Assistant</h3>
              <div className="ai-static-preview">
                <div className="ai-bubble ai-bubble--bot">Generate a login form with blue gradient</div>
                <div className="ai-bubble ai-bubble--user">Here&apos;s your component! ✨</div>
                <div className="ai-cta-hint">Try it →</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section className="how-it-works" aria-labelledby="how-title">
        <h2 id="how-title" className="sr-only">How It Works</h2>
        <div className="steps">
          <div className="step animate"><div className="step-num">1</div><h3>Browse</h3><p>Pick from 160+ components across buttons, cards, forms, and systems.</p></div>
          <div className="step animate"><div className="step-num">2</div><h3>Preview</h3><p>See live previews and switch between HTML, CSS, and JS tabs.</p></div>
          <div className="step animate"><div className="step-num">3</div><h3>Copy</h3><p>One-click copy the code and paste it directly into your project.</p></div>
          <div className="step animate"><div className="step-num">4</div><h3>Customise</h3><p>Use the AI assistant to modify or generate new components on demand.</p></div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="cta-section" aria-labelledby="cta-title">
        <h2 id="cta-title">Ready to Build Faster?</h2>
        <p>Start exploring 160+ free UI components and save hours of coding time.</p>
        <a href="/buttons" className="cta-btn">
          <i className="fas fa-rocket" aria-hidden="true" /> Get Started Free
        </a>
      </section>

      {/* Page-specific JS */}
      <Script src="/js/home.js" strategy="afterInteractive" />
    </>
  );
}
