/**
 * app/api/vision/route.ts
 *
 * POST /api/vision
 * Body: { prompt?: string; imageBase64: string; imageType: string }
 * Response: { html: string; css: string; js: string; name: string }
 *
 * Accepts images up to ~5 MB (base64 ≈ 7 MB string).
 */
import { NextRequest, NextResponse } from "next/server";
import {
  callAnthropicVision,
  parseJsonResponse,
} from "@/lib/anthropic";
import { isRateLimited } from "@/lib/rateLimit";
import { corsHeaders, handleOptions, corsError } from "@/lib/cors";

export const runtime = "nodejs";

/* Allow larger bodies for base64 images */
export const config = {
  api: { bodyParser: { sizeLimit: "8mb" } },
};

/* ── Pre-flight ─────────────────────────────────── */
export function OPTIONS(req: NextRequest) {
  return handleOptions(req.headers.get("origin"));
}

/* ── Allowed image MIME types ───────────────────── */
const ALLOWED_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
]);

/* ── POST handler ───────────────────────────────── */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const origin = req.headers.get("origin");
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ??
    req.headers.get("x-real-ip") ??
    "unknown";

  /* Rate limit (vision is more expensive — stricter 15 rpm) */
  if (isRateLimited(ip)) {
    return corsError("Too many requests. Please wait a moment.", 429, origin);
  }

  /* Parse body */
  let body: {
    prompt?:      unknown;
    imageBase64?: unknown;
    imageType?:   unknown;
  };
  try {
    body = await req.json();
  } catch {
    return corsError("Invalid JSON body.", 400, origin);
  }

  const { prompt, imageBase64, imageType } = body;

  if (!imageBase64 || typeof imageBase64 !== "string") {
    return corsError("`imageBase64` is required.", 400, origin);
  }
  if (!imageType || typeof imageType !== "string") {
    return corsError("`imageType` is required.", 400, origin);
  }
  if (!ALLOWED_TYPES.has(imageType)) {
    return corsError(
      `Unsupported image type: ${imageType}. Use JPEG, PNG, GIF or WebP.`,
      400,
      origin
    );
  }

  const promptText =
    typeof prompt === "string" && prompt.trim()
      ? prompt.trim()
      : "Analyze this UI design and generate matching HTML+CSS+JS code.";

  /* Call Anthropic Vision */
  try {
    const raw = await callAnthropicVision({
      prompt:      promptText,
      imageBase64,
      imageType,
    });

    interface VisionResponse {
      html: string;
      css:  string;
      js:   string;
      name: string;
    }

    let parsed: VisionResponse;
    try {
      parsed = parseJsonResponse<VisionResponse>(raw);
    } catch {
      console.error("[/api/vision] JSON parse failed:", raw.slice(0, 300));
      return corsError(
        "Model returned an invalid format. Please try again.",
        502,
        origin
      );
    }

    if (!parsed.html || !parsed.css) {
      return corsError("Incomplete component returned.", 502, origin);
    }

    return NextResponse.json(parsed, { headers: corsHeaders(origin) });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    console.error("[/api/vision]", msg);

    if (msg.includes("401") || msg.includes("authentication")) {
      return corsError("Invalid Anthropic API key.", 401, origin);
    }
    return corsError("Failed to analyse image.", 500, origin);
  }
}
