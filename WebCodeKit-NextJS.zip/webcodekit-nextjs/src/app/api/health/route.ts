/**
 * app/api/health/route.ts
 *
 * GET /api/health
 * Public health-check endpoint — returns server status and model config.
 * Safe to expose: contains NO secrets.
 */
import { NextRequest, NextResponse } from "next/server";
import { corsHeaders, handleOptions } from "@/lib/cors";

export const runtime = "nodejs";

export function OPTIONS(req: NextRequest) {
  return handleOptions(req.headers.get("origin"));
}

export function GET(req: NextRequest): NextResponse {
  const origin = req.headers.get("origin");

  return NextResponse.json(
    {
      status:    "ok",
      model:     process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-6",
      apiReady:  Boolean(process.env.ANTHROPIC_API_KEY),
      timestamp: new Date().toISOString(),
    },
    { headers: corsHeaders(origin) }
  );
}
