/**
 * app/api/chat/route.ts
 *
 * POST /api/chat
 * Body: { message: string; history?: ChatMessage[] }
 * Response: { reply: string }
 */
import { NextRequest, NextResponse } from "next/server";
import {
  callAnthropic,
  sanitizeHistory,
  CHAT_SYSTEM_PROMPT,
  type ChatMessage,
} from "@/lib/anthropic";
import { isRateLimited, retryAfter } from "@/lib/rateLimit";
import { corsHeaders, handleOptions, corsError } from "@/lib/cors";

export const runtime = "nodejs";

/* ── Pre-flight ─────────────────────────────────── */
export function OPTIONS(req: NextRequest) {
  return handleOptions(req.headers.get("origin"));
}

/* ── POST handler ───────────────────────────────── */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const origin = req.headers.get("origin");
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ??
    req.headers.get("x-real-ip") ??
    "unknown";

  /* Rate limit */
  if (isRateLimited(ip)) {
    return corsError(
      "Too many requests. Please wait a moment.",
      429,
      origin
    );
  }

  /* Parse body */
  let body: { message?: unknown; history?: unknown };
  try {
    body = await req.json();
  } catch {
    return corsError("Invalid JSON body.", 400, origin);
  }

  const { message, history } = body;

  if (!message || typeof message !== "string" || !message.trim()) {
    return corsError("`message` is required.", 400, origin);
  }

  /* Build messages array */
  const messages: ChatMessage[] = [
    ...sanitizeHistory(history),
    { role: "user", content: message.trim() },
  ];

  /* Call Anthropic */
  try {
    const reply = await callAnthropic({
      system:     CHAT_SYSTEM_PROMPT,
      messages,
      max_tokens: 1000,
    });

    return NextResponse.json(
      { reply },
      { headers: corsHeaders(origin) }
    );
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Unknown error";
    console.error("[/api/chat]", message);

    if (message.includes("401") || message.includes("authentication")) {
      return corsError("Invalid Anthropic API key.", 401, origin);
    }
    return corsError("Failed to generate reply.", 500, origin);
  }
}
