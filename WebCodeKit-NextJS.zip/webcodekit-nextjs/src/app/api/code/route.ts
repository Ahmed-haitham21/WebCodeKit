/**
 * app/api/code/route.ts
 *
 * POST /api/code
 * Body: { prompt: string; history?: ChatMessage[] }
 * Response: { html: string; css: string; js: string; name: string }
 */
import { NextRequest, NextResponse } from "next/server";
import {
  callAnthropic,
  sanitizeHistory,
  parseJsonResponse,
  CODE_SYSTEM_PROMPT,
  type ChatMessage,
} from "@/lib/anthropic";
import { isRateLimited } from "@/lib/rateLimit";
import { corsHeaders, handleOptions, corsError } from "@/lib/cors";

export const runtime = "nodejs";

/* ── Pre-flight ─────────────────────────────────── */
export function OPTIONS(req: NextRequest) {
  return handleOptions(req.headers.get("origin"));
}

/* ── Component response shape ───────────────────── */
interface ComponentResponse {
  html: string;
  css:  string;
  js:   string;
  name: string;
}

/* ── POST handler ───────────────────────────────── */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const origin = req.headers.get("origin");
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ??
    req.headers.get("x-real-ip") ??
    "unknown";

  /* Rate limit */
  if (isRateLimited(ip)) {
    return corsError("Too many requests. Please wait a moment.", 429, origin);
  }

  /* Parse body */
  let body: { prompt?: unknown; history?: unknown };
  try {
    body = await req.json();
  } catch {
    return corsError("Invalid JSON body.", 400, origin);
  }

  const { prompt, history } = body;

  if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
    return corsError("`prompt` is required.", 400, origin);
  }

  /* Build messages */
  const messages: ChatMessage[] = [
    ...sanitizeHistory(history),
    { role: "user", content: prompt.trim() },
  ];

  /* Call Anthropic */
  try {
    const raw = await callAnthropic({
      system:     CODE_SYSTEM_PROMPT,
      messages,
      max_tokens: 3000,
    });

    let parsed: ComponentResponse;
    try {
      parsed = parseJsonResponse<ComponentResponse>(raw);
    } catch {
      console.error("[/api/code] JSON parse failed:", raw.slice(0, 300));
      return corsError(
        "Model returned an invalid format. Please try again.",
        502,
        origin
      );
    }

    /* Basic validation */
    if (!parsed.html || !parsed.css) {
      return corsError("Incomplete component returned.", 502, origin);
    }

    return NextResponse.json(parsed, { headers: corsHeaders(origin) });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    console.error("[/api/code]", msg);

    if (msg.includes("401") || msg.includes("authentication")) {
      return corsError("Invalid Anthropic API key.", 401, origin);
    }
    return corsError("Failed to generate component.", 500, origin);
  }
}
