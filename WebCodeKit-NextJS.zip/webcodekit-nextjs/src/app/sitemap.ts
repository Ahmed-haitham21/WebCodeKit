/**
 * app/sitemap.ts
 * Generates /sitemap.xml automatically via Next.js Metadata API.
 */
import type { MetadataRoute } from "next";

const BASE = process.env.NEXT_PUBLIC_SITE_URL ?? "https://webcodekit.dev";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: `${BASE}/`,          changeFrequency: "weekly",  priority: 1.0  },
    { url: `${BASE}/buttons`,   changeFrequency: "monthly", priority: 0.9  },
    { url: `${BASE}/cards`,     changeFrequency: "monthly", priority: 0.9  },
    { url: `${BASE}/forms`,     changeFrequency: "monthly", priority: 0.9  },
    { url: `${BASE}/systems`,   changeFrequency: "monthly", priority: 0.8  },
    { url: `${BASE}/kits`,      changeFrequency: "monthly", priority: 0.8  },
    { url: `${BASE}/smart-ai`,  changeFrequency: "monthly", priority: 0.7  },
    { url: `${BASE}/about`,     changeFrequency: "yearly",  priority: 0.5  },
  ];
}
