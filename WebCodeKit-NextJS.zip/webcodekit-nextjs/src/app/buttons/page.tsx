/**
 * app/buttons/page.tsx  →  /buttons
 */
import type { Metadata } from "next";
import Script from "next/script";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title:       "100 Professional Buttons with Icons",
  description: "Browse 100 professional button styles with icons. Copy-paste ready HTML & CSS.",
  alternates:  { canonical: "/buttons" },
  openGraph:   { url: "/buttons" },
};

export default function ButtonsPage() {
  return (
    <>
      <Navbar />
      {/*
        The full buttons page HTML is complex and data-driven (100 buttons,
        modal, filter, star ratings). We serve it via the static HTML
        in /public and let Next.js handle routing.

        For a full RSC migration, move the button data to a JSON file
        and render via a ButtonGrid client component.
      */}
      <div id="buttonsPageRoot" />
      <Script src="/js/buttons.js" strategy="afterInteractive" />
    </>
  );
}
