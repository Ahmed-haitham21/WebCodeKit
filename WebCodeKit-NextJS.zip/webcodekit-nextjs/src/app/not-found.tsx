/**
 * app/not-found.tsx
 * Custom 404 page.
 */
import type { Metadata } from "next";
import Link from "next/link";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "404 — Page Not Found",
  description: "The page you are looking for does not exist. Return to WebCodeKit.",
};

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main className="page-404" aria-labelledby="error-title">
        <div className="error-number" aria-hidden="true">404</div>
        <h1 className="error-title" id="error-title">Page Not Found</h1>
        <p className="error-desc">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>
        <div className="error-actions">
          <Link href="/" className="error-btn error-btn--primary">
            <i className="fas fa-home" aria-hidden="true" /> Go Home
          </Link>
          <Link href="/buttons" className="error-btn">
            <i className="fas fa-th-large" aria-hidden="true" /> Browse Components
          </Link>
        </div>
      </main>
    </>
  );
}
