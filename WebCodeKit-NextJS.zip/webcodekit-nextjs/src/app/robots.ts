/**
 * app/robots.ts
 * Generates /robots.txt automatically.
 */
import type { MetadataRoute } from "next";

const BASE = process.env.NEXT_PUBLIC_SITE_URL ?? "https://webcodekit.dev";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow:     "/",
        disallow:  ["/api/"],   // Don't index API endpoints
      },
    ],
    sitemap: `${BASE}/sitemap.xml`,
  };
}
