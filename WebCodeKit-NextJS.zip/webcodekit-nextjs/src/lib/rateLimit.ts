/**
 * lib/rateLimit.ts
 * Simple in-memory sliding-window rate limiter.
 * Works per-IP across all API routes.
 *
 * For production at scale, swap the in-memory store
 * with a Redis client (e.g. Upstash) — the interface stays identical.
 */

interface Window {
  count:     number;
  resetAt:   number;
}

const store = new Map<string, Window>();

const RPM = parseInt(process.env.RATE_LIMIT_RPM ?? "30", 10);
const WINDOW_MS = 60_000; // 1 minute

/** Returns true if the request should be blocked */
export function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const entry = store.get(ip);

  if (!entry || now >= entry.resetAt) {
    // Fresh window
    store.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return false;
  }

  entry.count += 1;
  if (entry.count > RPM) return true;

  return false;
}

/** How many seconds until the client's window resets */
export function retryAfter(ip: string): number {
  const entry = store.get(ip);
  if (!entry) return 0;
  return Math.max(0, Math.ceil((entry.resetAt - Date.now()) / 1000));
}

/* Periodically sweep stale entries to avoid memory growth */
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of store) {
      if (now >= entry.resetAt) store.delete(key);
    }
  }, WINDOW_MS);
}
