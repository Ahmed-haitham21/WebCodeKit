/**
 * lib/anthropic.ts
 * Shared helpers for calling the Anthropic API from Next.js API routes.
 */

/* ── Types ─────────────────────────────────────── */
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface AnthropicCallOptions {
  system: string;
  messages: ChatMessage[];
  max_tokens: number;
}

/* ── Config ─────────────────────────────────────── */
const API_KEY   = process.env.ANTHROPIC_API_KEY ?? "";
const MODEL     = process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-6";
const API_URL   = "https://api.anthropic.com/v1/messages";
const API_VER   = "2023-06-01";

/* ── System Prompts ─────────────────────────────── */
export const CHAT_SYSTEM_PROMPT = `You are a helpful AI assistant for WebCodeKit, a UI component library.
You answer questions about HTML, CSS, JavaScript, web development, and UI design in a friendly, clear way.
Respond in the same language the user uses (Arabic or English).
Keep answers concise and practical. Use examples when helpful.
Do NOT generate code blocks unless the user explicitly asks for code.`;

export const CODE_SYSTEM_PROMPT = `You are an expert UI component generator for WebCodeKit.
Return ONLY valid JSON with NO markdown, NO backticks, NO explanation — just raw JSON:
{"html":"...","css":"...","js":"...","name":"Component Name"}

STRICT RULES:
- Generate ONE polished, production-ready UI component
- Always dark-themed by default unless user says light
- CSS must be self-contained with unique class names (prefix: wck-)
- Use CSS variables: :root { --wck-primary: #667eea; --wck-secondary: #764ba2; }
- Add smooth transitions and hover effects
- Mobile responsive by default
- If user says modify/change/عدل/غير, refine the previous component
- If user asks for animation, add CSS keyframes
- Never use external images — use gradients or Font Awesome icons
- The component must look impressive and professional
- Return complete standalone code every time`;

export const VISION_SYSTEM_PROMPT = `You are a Design-to-Code expert. The user uploads a UI screenshot.
Analyze the design carefully and generate matching HTML+CSS+JS code.
Return ONLY valid JSON (no markdown, no backticks):
{"html":"...","css":"...","js":"...","name":"Component from Design"}

Rules:
- Match the layout, colors, and style as closely as possible
- Use dark theme if the design is dark, light theme if light
- Add hover effects and smooth transitions
- CSS class names must be prefixed with wck-
- Make it responsive
- Return complete, self-contained code`;

/* ── API Guard ──────────────────────────────────── */
export function assertApiKey(): void {
  if (!API_KEY) {
    throw new Error(
      "ANTHROPIC_API_KEY is not set. Add it to your .env.local file."
    );
  }
}

/* ── Sanitise conversation history ─────────────── */
export function sanitizeHistory(history: unknown): ChatMessage[] {
  if (!Array.isArray(history)) return [];
  return (history as unknown[])
    .filter(
      (m): m is ChatMessage =>
        typeof m === "object" &&
        m !== null &&
        "role" in m &&
        "content" in m &&
        ((m as ChatMessage).role === "user" ||
          (m as ChatMessage).role === "assistant") &&
        typeof (m as ChatMessage).content === "string"
    )
    .slice(-30)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }));
}

/* ── Core fetch wrapper ─────────────────────────── */
export async function callAnthropic(
  opts: AnthropicCallOptions
): Promise<string> {
  assertApiKey();

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type":      "application/json",
      "x-api-key":         API_KEY,
      "anthropic-version": API_VER,
    },
    body: JSON.stringify({
      model:      MODEL,
      max_tokens: opts.max_tokens,
      system:     opts.system,
      messages:   opts.messages,
    }),
    // Next.js fetch: don't cache AI responses
    cache: "no-store",
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Anthropic API error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const text =
    (data.content as Array<{ type: string; text?: string }>)?.find(
      (b) => b.type === "text"
    )?.text ?? "";
  return text;
}

/* ── Parse JSON from model (strips accidental markdown fences) ── */
export function parseJsonResponse<T>(raw: string): T {
  const clean = raw.replace(/```json\s*|```/g, "").trim();
  return JSON.parse(clean) as T;
}

/* ── Vision call (multimodal) ───────────────────── */
export interface VisionCallOptions {
  prompt: string;
  imageBase64: string;
  imageType: string;
}

export async function callAnthropicVision(
  opts: VisionCallOptions
): Promise<string> {
  assertApiKey();

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type":      "application/json",
      "x-api-key":         API_KEY,
      "anthropic-version": API_VER,
    },
    body: JSON.stringify({
      model:      MODEL,
      max_tokens: 4000,
      system:     VISION_SYSTEM_PROMPT,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: {
                type:       "base64",
                media_type: opts.imageType,
                data:       opts.imageBase64,
              },
            },
            { type: "text", text: opts.prompt },
          ],
        },
      ],
    }),
    cache: "no-store",
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Anthropic Vision API error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const text =
    (data.content as Array<{ type: string; text?: string }>)?.find(
      (b) => b.type === "text"
    )?.text ?? "";
  return text;
}
