/**
 * lib/cors.ts
 * Reusable CORS helper for Next.js API Route Handlers.
 */
import { NextResponse } from "next/server";

const ALLOWED_ORIGIN =
  process.env.ALLOWED_ORIGIN?.trim() || "*";

/** Build CORS headers object */
export function corsHeaders(origin?: string | null): HeadersInit {
  const allow =
    ALLOWED_ORIGIN === "*"
      ? "*"
      : origin && origin === ALLOWED_ORIGIN
      ? origin
      : ALLOWED_ORIGIN;

  return {
    "Access-Control-Allow-Origin":  allow,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, x-api-key",
    "Access-Control-Max-Age":       "86400",
  };
}

/** Handle pre-flight OPTIONS automatically */
export function handleOptions(origin?: string | null): NextResponse {
  return new NextResponse(null, {
    status: 204,
    headers: corsHeaders(origin),
  });
}

/** Wrap a JSON error response with CORS headers */
export function corsError(
  message: string,
  status: number,
  origin?: string | null
): NextResponse {
  return NextResponse.json(
    { error: message },
    { status, headers: corsHeaders(origin) }
  );
}
