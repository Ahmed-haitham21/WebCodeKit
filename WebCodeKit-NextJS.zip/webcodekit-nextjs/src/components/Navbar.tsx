"use client";
/**
 * components/Navbar.tsx
 * Shared navigation bar — rendered on every page via layout.tsx.
 * Active link is detected client-side (usePathname).
 */
import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_LINKS = [
  { href: "/",           label: "Home"         },
  { href: "/buttons",    label: "Buttons"       },
  { href: "/cards",      label: "Cards"         },
  { href: "/forms",      label: "Forms"         },
  { href: "/systems",    label: "Systems"       },
  { href: "/kits",       label: "Kits"          },
  { href: "/smart-ai",   label: "AI Assistant", className: "nav-ai-link" },
  { href: "/about",      label: "About Us"      },
];

const MOBILE_LINKS = [
  ...NAV_LINKS,
  { href: "/favorites",  label: "My Favorites", className: "mobile-fav-link" },
];

export default function Navbar() {
  const pathname = usePathname();

  function isActive(href: string) {
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  }

  return (
    <>
      <nav className="navbar" role="navigation" aria-label="Main navigation">
        <div className="logo-hamburger-wrapper">
          {/* Hamburger — wired up by navbar.js */}
          <button
            className="hamburger"
            id="hamburger"
            aria-label="Toggle menu"
            aria-expanded="false"
          >
            <span />
            <span />
            <span />
          </button>

          <Link href="/" className="logo">
            <i className="fas fa-code" aria-hidden="true" />
            <span className="logo-text">
              Web<span className="logo-accent">CodeKit</span>
            </span>
          </Link>
        </div>

        {/* Desktop nav */}
        <ul className="nav-links" role="list">
          {NAV_LINKS.map(({ href, label, className }) => (
            <li key={href}>
              <Link
                href={href}
                className={[
                  className,
                  isActive(href) ? "nav-active" : "",
                ]
                  .filter(Boolean)
                  .join(" ")}
              >
                {label}
              </Link>
            </li>
          ))}
        </ul>

        {/* Favourites icon */}
        <Link
          href="/favorites"
          className="nav-fav-link"
          title="My Favorites"
          aria-label="My Favorites"
        >
          <i className="fas fa-heart" aria-hidden="true" />
        </Link>

        {/* Theme toggle pill — wired up by theme-toggle.js */}
        <button
          className="theme-btn"
          id="theme-toggle-btn"
          onClick={() => {
            if (typeof window !== "undefined" && (window as Window & { toggleTheme?: () => void }).toggleTheme) {
              (window as Window & { toggleTheme?: () => void }).toggleTheme?.();
            }
          }}
          title="Switch to Light Mode"
          aria-label="Switch to Light Mode"
        >
          <div
            className="theme-toggle-pill"
            id="theme-toggle-pill"
            data-mode="dark"
          >
            <span className="theme-toggle-track">
              <span className="theme-toggle-icon theme-icon-moon">
                <i className="fas fa-moon" aria-hidden="true" />
              </span>
              <span className="theme-toggle-icon theme-icon-sun">
                <i className="fas fa-sun" aria-hidden="true" />
              </span>
            </span>
            <span className="theme-toggle-thumb" />
          </div>
        </button>
      </nav>

      {/* Mobile menu */}
      <ul
        className="mobile-menu"
        id="mobileMenu"
        role="list"
        aria-label="Mobile navigation"
      >
        {MOBILE_LINKS.map(({ href, label, className }) => (
          <li key={href}>
            <Link
              href={href}
              className={[
                className,
                isActive(href) ? "nav-active" : "",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              {href === "/favorites" && (
                <i className="fas fa-heart" aria-hidden="true" />
              )}{" "}
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}
