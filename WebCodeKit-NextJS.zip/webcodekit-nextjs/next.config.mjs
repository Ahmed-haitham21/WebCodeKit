/** @type {import('next').NextConfig} */
const nextConfig = {
  /* ── Security headers ── */
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options",    value: "nosniff" },
          { key: "X-Frame-Options",           value: "DENY" },
          { key: "X-XSS-Protection",          value: "1; mode=block" },
          { key: "Referrer-Policy",           value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy",        value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },

  /* ── CORS handled per-route in API handlers ── */

  /* ── Image optimisation ── */
  images: {
    formats: ["image/avif", "image/webp"],
  },

  /* ── Experimental ── */
  experimental: {
    serverComponentsExternalPackages: [],
  },
};

export default nextConfig;
